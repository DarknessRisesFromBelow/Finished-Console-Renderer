namespace ConsoleRenderer.Maths
{
	
}